package tests;

import static org.junit.jupiter.api.Assertions.*;

import program.InsuranceCalculator;
import program.InsurancePerson;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * Class for Testing InsuranceCalculator and InsurancePerson
 */
class InsuranceTestingSuit {

    /**
     * Required Attributes for Testing
     */
    public static InsurancePerson[] insuranceCustomerDatabase;
    InsuranceCalculator insuranceCalculator;

    /**
     * This Method Run After All the Tests and make insuranceDatabase Attribute to Null
     */
    @AfterAll
    public static void afterAllMethod(){
        insuranceCustomerDatabase = null;
        System.out.println("Tests are Completed:");
    }

    /**
     * This method Run Before All the tests and Generate Number of insuranceclasses.InsurancePerson Objects
     * This Method Generate Random Values for insuranceclasses.InsurancePerson Class Objects
     */
    @BeforeAll
    public static void beforeAllMethod(){
        insuranceCustomerDatabase = new InsurancePerson[getRandom(59, 1000)];
        for (int i = 0; i < insuranceCustomerDatabase.length; i++) {
            insuranceCustomerDatabase[i] =  new InsurancePerson(getRandom(12,50), getRandom(0,10));
        }
    }


    /**
     * This method Assign Random Value to Calculator for Each Test
     */
    @BeforeEach
    void setUp() {
        insuranceCalculator = new InsuranceCalculator(getRandom(50, 119), getRandom(300,1000));
    }


    /**
     * This method assign null value for Each Insurance Calculator
     */
    @AfterEach
    void tearDown() {
        insuranceCalculator = null;
    }

    /**
     * Test for canGetInsurance Method of insuranceclasses.InsuranceCalculator
     */
    @Order(0)
    @DisplayName("Testing canGetInsurance(insuranceclasses.InsurancePerson ) Method:")
    @RepeatedTest(25)
    void canGetInsurance() {
        InsurancePerson ip = insuranceCustomerDatabase[getRandom(0, insuranceCustomerDatabase.length-1)];
        assertEquals(ip.getAccidents() <= 5, insuranceCalculator.canGetInsurance(ip));
    }

    /**
     * Test for canGetSurcharge Method of insuranceclasses.InsuranceCalculator
     */
    @Order(1)
    @DisplayName("Testing canGetSurcharge(insuranceclasses.InsurancePerson ) Method:")
    @RepeatedTest(25)
    void canGetSurcharge() {
        InsurancePerson ip = insuranceCustomerDatabase[getRandom(0, insuranceCustomerDatabase.length-1)];
        assertEquals(ip.getAge() <= 25, insuranceCalculator.canGetSurcharge(ip));
    }

    /**
     * Test for canGetSurcharge Method
     */
    @Order(2)
    @DisplayName("Testing canGetSurcharge(insuranceclasses.InsurancePerson ) Method:")
    @RepeatedTest(25)
    void getAdditionalCharges() {
        InsurancePerson ip = insuranceCustomerDatabase[getRandom(0, insuranceCustomerDatabase.length-1)];
        int additionalCharge = switch (ip.getAccidents()) {
            case 1 -> 50;
            case 2 -> 125;
            case 3 -> 225;
            case 4 -> 375;
            case 5 -> 575;
            default -> 0;
        };
        assertEquals(additionalCharge, insuranceCalculator.getAdditionalCharges(ip));
    }

    /**
     * Test calculateInsurance method
     */
    @Order(3)
    @DisplayName("Testing calculateInsurance(insuranceclasses.InsurancePerson ) Method:")
    @RepeatedTest(25)
    void calculateInsurance() {
        InsurancePerson ip = insuranceCustomerDatabase[getRandom(0, insuranceCustomerDatabase.length-1)];

        if(ip.getAge()%2 == 0){
            ip = null;
        }

        int insuranceAmount = 0;
        if(insuranceCalculator.canGetInsurance(ip)) {
            if(insuranceCalculator.canGetSurcharge(ip))
                insuranceAmount += insuranceCalculator.getSurcharge();
            insuranceAmount += insuranceCalculator.getAdditionalCharges(ip);
        }

        assertEquals(insuranceAmount, insuranceCalculator.calculateInsurance(ip));
    }

    /**
     * Parametrized Test for Testing negative Values
     */
    @DisplayName("Testing Negative Values")
    @ParameterizedTest
    @ValueSource(strings = { "0,0","-1,-1","-1,0","0,-1"})
    void borderValuesTests(String data){
        String[] splitedValues = data.split(",");
        InsuranceCalculator ic = new InsuranceCalculator(Integer.parseInt(splitedValues[0]),Integer.parseInt(splitedValues[1]));
        assertEquals(0, ic.getBasicInsurance(),"Return Should be 0 for BasicInsurance in Insurance Calculator");
        assertEquals(0, ic.getSurcharge(),"Return Should be 0 for Surcharge in Insurance Calculator");

        InsurancePerson ip = new InsurancePerson(Integer.parseInt(splitedValues[0]),Integer.parseInt(splitedValues[1]));
       // assertEquals(1, ip.getAge(),"Age should be 1");
        assertEquals(0, ip.getAccidents(),"Accidents Should be 0");
    }

    /**
     * @param min minimum Value
     * @param max maximum Value
     * @return int between interval (min, max)
     */
    public static int getRandom(int min, int max){
        return (int) ((Math.random() * (max - min)) + min);
    }
}