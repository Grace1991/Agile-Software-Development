package program;

/**
 * This is Insurance Calculator Class, it Calculate Insurance to pay
 * according to Accidents and Age
 */
public class InsuranceCalculator {

    /*
     * Attributes:
     * basicInsurance: it is Basic Insurance to pay Customer
     * Surcharge: Charges to pay Customer on Age Distribution
     */
    private int basicInsurance;
    private int surcharge;

    /**
     * Constructor: default Constructor
     */
    public InsuranceCalculator() {
    }

    /**
     * Parametrized Constructor: int, int
     * @param basicInsurance basicInsurance for Calculator
     * @param surcharge Surcharge for Calculator
     */
    public InsuranceCalculator(int basicInsurance, int surcharge) {
        setBasicInsurance(basicInsurance);
        setSurcharge(surcharge);
    }

    //Getter and Setter Method

    /**
     * Getter for basicInsurance Attribute
     * @return basicInsurance
     */
    public int getBasicInsurance() {
        return basicInsurance;
    }

    /**
     * Setter for basicInsurance
     * @param basicInsurance value for basicInsurance Attribute
     */
    public void setBasicInsurance(int basicInsurance) {
        this.basicInsurance = Math.max(basicInsurance, 0); //assign 0 if less than 0 else given Number
    }

    /**
     * Getter for surcharge Attribute of Class
     * @return surcharge
     */
    public int getSurcharge() {
        return surcharge;
    }

    /**
     * Setter for surcharge Attribute
     * @param surcharge value for surcharge Attribute
     */
    public void setSurcharge(int surcharge) {
        this.surcharge = Math.max(surcharge, 0); //assign 0 if less than 0 else given Number
    }

    //Other Methods

    /**
     * if accidents less than 5 : Can get Insurance
     * else: no Insurance
     * @param ip insuranceclasses.InsurancePerson Object
     * @return true / false
     */
    public boolean canGetInsurance(InsurancePerson ip) {
        if(ip == null)
            return false;
        return ip.getAccidents() <= 5;
    }

    /**
     * if age less than or equal than 25: customer can get surcharge
     * else: no surcharge
     * @param ip insuranceclasses.InsurancePerson Object
     * @return true / false
     */
    public boolean canGetSurcharge(InsurancePerson ip){
        if(ip == null)
            return false;
        return ip.getAge() <= 25;
    }

    /**
     * Additional Charges for Accidents
     * @param x Number of Accidents Customer Encounter
     * @return int, Charges Corresponding to Accidents
     */
    public int getAdditionalCharges(InsurancePerson x){
        if(x == null)
            return 0;
        return switch (x.getAccidents()) {
            case 1 -> 50;
            case 2 -> 125;
            case 3 -> 225;
            case 4 -> 375;
            case 5 -> 575;
            default -> 0;
        };
    }

    /**
     * Method Calculate Insurance for Person
     * @param ip insuranceclasses.InsurancePerson Class Object Required for it
     * @return int, total Insurance
     */
    public int calculateInsurance(InsurancePerson ip) {
        if(ip == null)
            return 0;
        if(canGetInsurance(ip)) {
            int insuranceAmount = 0;
            if(canGetSurcharge(ip))
                insuranceAmount += this.getSurcharge();
            insuranceAmount += this.getAdditionalCharges(ip);
            return insuranceAmount;
        }
        return 0;
    }

}