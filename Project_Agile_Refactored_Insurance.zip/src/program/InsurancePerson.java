package program;

/**
 * Class used as a Customer for InsuranceCalculator
 */

public class InsurancePerson {
    /*
    *Attributes
    */
    private int age;
    private int accidents;

    /**
     * Parametrized Constructor
     * @param age age of Customer
     * @param accidents Number of Accidents Customer Encounter
     */
    public InsurancePerson(int age, int accidents) {
        setAccidents(accidents);
        setAge(age);
    }

    /**
     * Default Constructor
     */
    public InsurancePerson() {
    }

    /**
     *Getter and Setter
     */

    /**
     * @return age of Customer
     */
    public int getAge() {
        return age;
    }

    /**
     * This method Accept age only Greater than zero else 1
     * @param age age of Customer
     */
    public void setAge(int age) {
        if(age <= 0)
            this.age = 1;
        else
            this.age = age;
    }

    /**
     * @return number of accidents customer encounter
     */
    public int getAccidents() {
        return accidents;
    }

    /**
     * This method assign Accidents only greater than equal to zero else 0
     * @param accidents number of accidents customer Encounter
     */
    public void setAccidents(int accidents) {
        this.accidents = Math.max(accidents, 0); //assign 0 if less than 0 else given Number
    }
}
